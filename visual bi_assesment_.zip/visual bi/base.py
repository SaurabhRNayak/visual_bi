from flask import Flask,request,render_template,Response
import sqlite3
import requests

'''
steps:
to make a fresh sync use (the local host may vary depending on the system)
    ->http://127.0.0.1:5000/jobs/sync/
to make filter based on location use
    ->http://127.0.0.1:5000/jobs/location/russia
    (russia value must be changed depending on the search)
to make filter based on title use
    ->http://127.0.0.1:5000/jobs/location/software_dev
    (software_dev value must be changed depending on the search)
'''

app=Flask(__name__)

@app.route('/jobs/sync/',methods=['POST','GET'])
def sync_():

    sql_conn=sqlite3.connect('my_job.db')
    cursor=sql_conn.cursor()
    drop='drop table if exists jobs;'
    create='create table jobs (company_name TEXT ,title TEXT, location TEXT, description TEXT);'
    cursor.execute(drop)
    cursor.execute(create)
    fill(cursor)
    sql_conn.commit()
    cursor.close()
    return ("<H1>sync_complete<H1>")

global path
'''change the template path to the path the files are copied correctly path = r'<this path>\visual bi\templates'''''
path = r'E:\py_works\visual bi\templates'
global head
head = """<!DOCTYPE html><head>
    <meta charset="UTF-8">
    <title>jobs</title>
    </head>
    <body>
    <table>
        <tr><th><H1>company_name</h1></th> 
        <th><h1>title</h1></th>
        <th><h1>location</h1></th>
        </tr>
        \n"""
global body
body = """
        <tr>
        <td>{com}</td>
        <td>{tit}</td>
        <td>{loc}</td>
        </tr>

        """

@app.route('/jobs/title/<name>',methods=['POST','GET'])
def dispt_(name):
    if name==None:
        disp_()
    else:
        sql_conn = sqlite3.connect('my_job.db')
        cursor = sql_conn.cursor()
        sel = 'select * from jobs where title like \'%'+name+'%\';'
        cursor.execute(sel)
        ans = cursor.fetchall()
        if (len(ans))==0:
            return('<h1>No match Found</h1>')

        with open(path+'\\disp.html', 'w') as f:
            f.writelines(head)
            for i in ans:
                f.writelines(body.format(com=i[0], tit=i[1], loc=i[2]))

            f.writelines('</table></body></html>')

        return render_template("disp.html")

@app.route('/jobs/location/<name>',methods=['POST','GET'])
def displ_(name):
    if name==None:
        disp_()
    else:
        sql_conn = sqlite3.connect('my_job.db')
        cursor = sql_conn.cursor()
        sel = 'select * from jobs where location like \'%'+name+'%\';'
        cursor.execute(sel)
        ans = cursor.fetchall()
        if (len(ans))==0:
            return('<h1>No match Found</h1>')
        with open(path+'\\disp.html', 'w') as f:
            f.writelines(head)
            for i in ans:
                f.writelines(body.format(com=i[0], tit=i[1], loc=i[2]))

            f.writelines('</table></body></html>')

        return render_template("disp.html")


@app.route('/jobs/', methods=['POST', 'GET'])
def disp_():
    sql_conn = sqlite3.connect('my_job.db')
    cursor = sql_conn.cursor()
    sel = 'select * from jobs;'
    cursor.execute(sel)
    ans = cursor.fetchall()
    print('all')
    with open(path+'\\disp.html', 'w') as f:
        f.writelines(head)
        for i in ans:
            f.writelines(body.format(com=i[0], tit=i[1], loc=i[2]))

        f.writelines('</table></body></html>')

    return render_template("disp.html")

def fill(cursor):
    global url
    url = "https://jobs.github.com/positions.json?"
    response = requests.get(url)
    dat = response.json()
    insert='insert into jobs(company_name,title,location) values({com},{tit},{loc})'
    for i in (dat):
        # com=("'"+i['company']+"'").encode('utf-8',errors='ignore')
        # tit=("'"+i['title']+"'").encode('utf-8',errors='ignore')
        # loc=("'"+i['location']+"'").encode('utf-8',errors='ignore')
        # print(com,tit,loc)
        # print(insert.format(com=com.decode('utf-8'),tit=tit.decode('utf-8'),loc=loc.decode('utf-8')))
        # cursor.execute(insert.format(com=com.decode('utf-8'),tit=tit.decode('utf-8'),loc=loc.decode('utf-8')))
        com = ("'" + i['company'] + "'").replace(' – ','').replace('ü','')
        tit = ("'" + i['title'] + "'").replace(' – ','').replace('ü','')
        loc = ("'" + i['location'] + "'").replace(' – ','').replace('ü','')
        # print(com, tit, loc)
        print(insert.format(com=com, tit=tit, loc=loc))
        cursor.execute(insert.format(com=com, tit=tit, loc=loc))

if __name__=='__main__':
    global url
    url="https://jobs.github.com/positions.json?"
    response=requests.get(url)
    # print (response.content)
    dat=response.json()
    print(dat[0].keys())
    # dict_keys(['id', 'type', 'url', 'created_at', 'company', 'company_url', 'location', 'title', 'description',
    #            # 'how_to_apply', 'company_logo'])
    app.run(debug=True)